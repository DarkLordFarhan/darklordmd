/**
 * DarkLords MD — DarklordFarhan WhatsApp Bot
 * Uses bundled Baileys (./baileys)
 */
import makeWASocket, {
  useMultiFileAuthState,
  DisconnectReason,
  fetchLatestBaileysVersion,
  Browsers,
  makeCacheableSignalKeyStore,
} from "baileys";
import { Boom } from "@hapi/boom";
import pino from "pino";
import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";
import qrcode from "qrcode-terminal";
import config from "./config.js";
import { handleMessage } from "./lib/handler.js";
import { loadPlugins } from "./lib/plugins.js";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const logger = pino({ level: "silent" });
const SESSION_DIR = path.join(__dirname, "session");
if (!fs.existsSync(SESSION_DIR)) fs.mkdirSync(SESSION_DIR, { recursive: true });

const banner = `
╔══════════════════════════════════════╗
║        DARKLORDS  MD  BOT            ║
║      by  DarklordFarhan              ║
╚══════════════════════════════════════╝
`;

async function start() {
  console.log(banner);
  const { state, saveCreds } = await useMultiFileAuthState(SESSION_DIR);
  const { version } = await fetchLatestBaileysVersion();

  const sock = makeWASocket({
    version,
    logger,
    printQRInTerminal: false,
    browser: Browsers.macOS("Safari"),
    auth: {
      creds: state.creds,
      keys: makeCacheableSignalKeyStore(state.keys, logger),
    },
    generateHighQualityLinkPreview: true,
  });

  if (!sock.authState.creds.registered && config.pairNumber) {
    await new Promise((r) => setTimeout(r, 1500));
    try {
      const code = await sock.requestPairingCode(config.pairNumber.replace(/[^0-9]/g, ""));
      const formatted = code?.match(/.{1,4}/g)?.join("-") || code;
      console.log("\n══════════════════════════════════════");
      console.log("   🔑  PAIRING CODE:  " + formatted);
      console.log("══════════════════════════════════════\n");
      console.log("WhatsApp → Linked Devices → Link with phone number → enter the code above.\n");
    } catch (e) {
      console.error("Pair code error:", e.message);
    }
  }

  const plugins = await loadPlugins();
  console.log(`[plugins] loaded ${plugins.length} commands`);

  sock.ev.on("creds.update", saveCreds);

  sock.ev.on("connection.update", (u) => {
    const { connection, lastDisconnect, qr } = u;
    if (qr && !config.pairNumber) qrcode.generate(qr, { small: true });
    if (connection === "close") {
      const code = new Boom(lastDisconnect?.error)?.output?.statusCode;
      const reconnect = code !== DisconnectReason.loggedOut;
      console.log("[conn] closed, reconnect:", reconnect);
      if (reconnect) start();
    } else if (connection === "open") {
      console.log("[conn] ✅ DarkLords MD connected as", sock.user?.id);
      sock.sendMessage(sock.user.id, {
        text: `✨ *DarkLords MD* online\nOwner: ${config.ownerName}\nPrefix: ${config.prefix}\nMode: ${config.mode}`,
      }).catch(() => {});
    }
  });

  sock.ev.on("messages.upsert", async (m) => {
    try { await handleMessage(sock, m, plugins); }
    catch (e) { console.error("msg error:", e); }
  });

  sock.ev.on("group-participants.update", async (ev) => {
    try {
      const meta = await sock.groupMetadata(ev.id);
      for (const p of ev.participants) {
        if (ev.action === "add") {
          await sock.sendMessage(ev.id, { text: `👋 Welcome @${p.split("@")[0]} to *${meta.subject}*`, mentions: [p] });
        } else if (ev.action === "remove") {
          await sock.sendMessage(ev.id, { text: `👋 Goodbye @${p.split("@")[0]}`, mentions: [p] });
        }
      }
    } catch {}
  });
}

start().catch((e) => { console.error(e); process.exit(1); });

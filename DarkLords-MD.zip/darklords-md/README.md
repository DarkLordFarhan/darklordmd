# DarkLords MD ⚡  (Pterodactyl-ready, bundled Baileys)

WhatsApp Multi-Device bot by **DarklordFarhan**, built on the **Baileys source you provided** (bundled in `./baileys`, no external Baileys download needed).

## ✨ Pterodactyl deployment (pair on Pterodactyl)

1. **Create server** with the Node.js egg (Node **20+** required by Baileys 7).
   - Recommended docker image: `ghcr.io/parkervcp/yolks:nodejs_20`
2. **Upload this whole folder** to the server (via SFTP or upload the ZIP and unzip in File Manager).
3. **Startup command:**
   ```
   npm install --no-audit --no-fund && node index.js
   ```
   The first install also auto-builds the bundled Baileys (`prepare` script).
4. **Variables** (Settings → Startup):
   | Variable | Example | Required |
   |---|---|---|
   | `OWNER_NUMBER` | `923001234567` (no `+`) | ✅ |
   | `OWNER_NAME` | `DarklordFarhan` | ✅ |
   | `PAIR_NUMBER` | same as OWNER_NUMBER | ✅ first run |
   | `PREFIX` | `.` | ✅ |
   | `MODE` | `public` or `private` | ✅ |
   | `LOVABLE_API_KEY` | (from Lovable AI) | optional |
5. **Start the server.** Open the **Console** tab.
6. After ~10 seconds you'll see:
   ```
   ══════════════════════════════════════
      🔑  PAIRING CODE:  ABCD-1234
   ══════════════════════════════════════
   ```
7. On your phone: **WhatsApp → Settings → Linked Devices → Link with phone number → enter the code**.
8. Bot DMs you "DarkLords MD online". Type `.menu` anywhere.
9. **After pairing succeeds**, clear the `PAIR_NUMBER` variable and restart — the saved session will reconnect automatically.

## Local test

```bash
npm install
PAIR_NUMBER=923001234567 OWNER_NUMBER=923001234567 npm start
```

## Files

```
darklords-md/
├── baileys/         ← your uploaded Baileys source (bundled)
├── plugins/         ← drop a .js here to add a command
├── lib/             ← handler & plugin loader
├── session/         ← created at runtime
├── index.js         ← entry
├── pair.js          ← pair-only launcher
├── config.js
├── package.json     ← references baileys via "file:./baileys"
└── pterodactyl-egg.json
```

## Commands
`.menu .ping .alive .owner .runtime .yt .tiktok .insta .fb .kick .promote .demote .tagall .grouplink .sticker .quote .truth .dare .joke .fact .ai .img`

Made with 💜 by **DarklordFarhan**.

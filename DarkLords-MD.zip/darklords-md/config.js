// DarkLords MD configuration
export default {
  botName: process.env.BOT_NAME || "DarkLords MD",
  ownerName: process.env.OWNER_NAME || "DarklordFarhan",
  ownerNumber: process.env.OWNER_NUMBER || "923000000000",
  prefix: process.env.PREFIX || ".",
  mode: process.env.MODE || "public",
  pairNumber: process.env.PAIR_NUMBER || "",
  lovableApiKey: process.env.LOVABLE_API_KEY || "",
  aiModel: process.env.AI_MODEL || "google/gemini-3-flash-preview",
  autoRead: process.env.AUTO_READ === "true",
  autoTyping: process.env.AUTO_TYPING === "true",
};

// Standalone pair launcher: PAIR_NUMBER=923001234567 node pair.js
process.env.PAIR_NUMBER = process.env.PAIR_NUMBER || process.argv[2] || "";
if (!process.env.PAIR_NUMBER) {
  console.error("Usage: node pair.js <number>   e.g. node pair.js 923001234567");
  process.exit(1);
}
await import("./index.js");

async function ensureAdmin(sock, from, sender) {
  const meta = await sock.groupMetadata(from);
  const me = sock.user.id.split(":")[0] + "@s.whatsapp.net";
  const isBotAdmin = meta.participants.some((p) => p.id === me && (p.admin === "admin" || p.admin === "superadmin"));
  const isUserAdmin = meta.participants.some((p) => p.id === sender && (p.admin === "admin" || p.admin === "superadmin"));
  if (!isBotAdmin) throw new Error("Bot must be admin");
  if (!isUserAdmin) throw new Error("Only admins");
  return meta;
}

export default [
  { name: "kick", run: async ({ sock, msg, from, sender, isGroup }) => {
    if (!isGroup) throw new Error("Group only"); await ensureAdmin(sock, from, sender);
    const t = msg.message?.extendedTextMessage?.contextInfo?.mentionedJid || [];
    if (!t.length) throw new Error("Mention a user");
    await sock.groupParticipantsUpdate(from, t, "remove");
  }},
  { name: "promote", run: async ({ sock, msg, from, sender, isGroup }) => {
    if (!isGroup) throw new Error("Group only"); await ensureAdmin(sock, from, sender);
    const t = msg.message?.extendedTextMessage?.contextInfo?.mentionedJid || [];
    await sock.groupParticipantsUpdate(from, t, "promote");
  }},
  { name: "demote", run: async ({ sock, msg, from, sender, isGroup }) => {
    if (!isGroup) throw new Error("Group only"); await ensureAdmin(sock, from, sender);
    const t = msg.message?.extendedTextMessage?.contextInfo?.mentionedJid || [];
    await sock.groupParticipantsUpdate(from, t, "demote");
  }},
  { name: "tagall", run: async ({ sock, msg, from, sender, isGroup, args }) => {
    if (!isGroup) throw new Error("Group only");
    const meta = await ensureAdmin(sock, from, sender);
    const text = args.join(" ") || "📢 Attention!";
    const mentions = meta.participants.map((p) => p.id);
    await sock.sendMessage(from, { text: `${text}\n\n` + mentions.map((j) => "• @" + j.split("@")[0]).join("\n"), mentions });
  }},
  { name: "grouplink", run: async ({ sock, msg, from, sender, isGroup }) => {
    if (!isGroup) throw new Error("Group only"); await ensureAdmin(sock, from, sender);
    const code = await sock.groupInviteCode(from);
    await sock.sendMessage(from, { text: "https://chat.whatsapp.com/" + code }, { quoted: msg });
  }},
];

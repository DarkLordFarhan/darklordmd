import axios from "axios";
import { Sticker, StickerTypes } from "wa-sticker-formatter";
import { downloadMediaMessage } from "baileys";

const truths = ["What's your biggest fear?", "Last lie you told?", "Biggest secret?", "Worst date ever?"];
const dares = ["Send a selfie", "Text your crush 'hi'", "Sing in voice note", "Do 10 pushups"];
const jokes = ["Why don't programmers like nature? Too many bugs.", "I told my computer I needed a break — it said 'No problem, I'll go to sleep.'"];
const facts = ["Octopuses have three hearts.", "Bananas are berries, strawberries aren't."];

export default [
  {
    name: "sticker", aliases: ["s"],
    run: async ({ sock, msg, from, config }) => {
      const target = msg.message?.extendedTextMessage?.contextInfo?.quotedMessage
        ? { message: msg.message.extendedTextMessage.contextInfo.quotedMessage, key: msg.key } : msg;
      const m = target.message || {};
      if (!m.imageMessage && !m.videoMessage) throw new Error("Reply to image/video");
      const buf = await downloadMediaMessage(target, "buffer", {});
      const sticker = new Sticker(buf, { pack: config.botName, author: config.ownerName, type: StickerTypes.FULL, quality: 60 });
      await sock.sendMessage(from, { sticker: await sticker.toBuffer() }, { quoted: msg });
    },
  },
  { name: "quote", run: async ({ sock, msg, from }) => {
    const { data } = await axios.get("https://zenquotes.io/api/random").catch(() => ({ data: [{ q: "Stay savage.", a: "Darklord" }] }));
    await sock.sendMessage(from, { text: `"${data[0].q}"\n— ${data[0].a}` }, { quoted: msg });
  }},
  { name: "truth", run: async ({ sock, msg, from }) => sock.sendMessage(from, { text: "🫣 " + truths[Math.floor(Math.random()*truths.length)] }, { quoted: msg }) },
  { name: "dare",  run: async ({ sock, msg, from }) => sock.sendMessage(from, { text: "😈 " + dares[Math.floor(Math.random()*dares.length)] }, { quoted: msg }) },
  { name: "joke",  run: async ({ sock, msg, from }) => sock.sendMessage(from, { text: "🤣 " + jokes[Math.floor(Math.random()*jokes.length)] }, { quoted: msg }) },
  { name: "fact",  run: async ({ sock, msg, from }) => sock.sendMessage(from, { text: "💡 " + facts[Math.floor(Math.random()*facts.length)] }, { quoted: msg }) },
];

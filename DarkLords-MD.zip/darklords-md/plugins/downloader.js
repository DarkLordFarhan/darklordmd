import axios from "axios";
import yts from "yt-search";
import ytdl from "@distube/ytdl-core";

async function ytDownload(query, sock, msg, from) {
  let url = query, title = query;
  if (!ytdl.validateURL(query)) {
    const r = await yts(query);
    if (!r.videos.length) throw new Error("No results");
    url = r.videos[0].url; title = r.videos[0].title;
  }
  const stream = ytdl(url, { filter: "audioandvideo", quality: "18" });
  const chunks = [];
  for await (const c of stream) chunks.push(c);
  await sock.sendMessage(from, { video: Buffer.concat(chunks), caption: `🎬 ${title}` }, { quoted: msg });
}

export default [
  {
    name: "yt", aliases: ["youtube", "play"],
    run: async ({ sock, msg, from, args }) => {
      if (!args.length) throw new Error("Usage: .yt <url|query>");
      await sock.sendMessage(from, { text: "⏳ Fetching from YouTube..." }, { quoted: msg });
      await ytDownload(args.join(" "), sock, msg, from);
    },
  },
  {
    name: "tiktok", aliases: ["tt"],
    run: async ({ sock, msg, from, args }) => {
      if (!args[0]) throw new Error("Usage: .tiktok <url>");
      const { data } = await axios.get(`https://tikwm.com/api/?url=${encodeURIComponent(args[0])}`, { timeout: 20000 });
      const link = data?.data?.play; if (!link) throw new Error("TikTok download failed");
      await sock.sendMessage(from, { video: { url: link }, caption: "📥 TikTok" }, { quoted: msg });
    },
  },
  {
    name: "insta", aliases: ["ig", "instagram"],
    run: async ({ sock, msg, from, args }) => {
      if (!args[0]) throw new Error("Usage: .insta <url>");
      const { data } = await axios.get(`https://api.dorratz.com/v2/instagram?url=${encodeURIComponent(args[0])}`, { timeout: 20000 });
      const link = data?.data?.[0]?.url || data?.url; if (!link) throw new Error("No media");
      await sock.sendMessage(from, { video: { url: link }, caption: "📥 Instagram" }, { quoted: msg });
    },
  },
  {
    name: "fb", aliases: ["facebook"],
    run: async ({ sock, msg, from, args }) => {
      if (!args[0]) throw new Error("Usage: .fb <url>");
      const { data } = await axios.get(`https://api.dorratz.com/fbvideo?url=${encodeURIComponent(args[0])}`, { timeout: 20000 });
      const link = data?.hd || data?.sd || data?.url; if (!link) throw new Error("No media");
      await sock.sendMessage(from, { video: { url: link }, caption: "📥 Facebook" }, { quoted: msg });
    },
  },
];

export default [
  {
    name: "menu", aliases: ["help", "list"],
    run: async ({ sock, msg, from, config: c }) => {
      const text = `╭━━〔 *${c.botName}* 〕━━╮
┃ Owner : ${c.ownerName}
┃ Prefix: ${c.prefix}
┃ Mode  : ${c.mode}
╰━━━━━━━━━━━━━━━━━╯

📌 *CORE*
${c.prefix}menu  ${c.prefix}ping  ${c.prefix}alive  ${c.prefix}owner  ${c.prefix}runtime

🎬 *DOWNLOADER*
${c.prefix}yt <url|query>
${c.prefix}tiktok <url>
${c.prefix}insta <url>
${c.prefix}fb <url>

👮 *GROUP*
${c.prefix}kick @user   ${c.prefix}promote @user
${c.prefix}demote @user ${c.prefix}tagall <text>
${c.prefix}grouplink

🎭 *FUN*
${c.prefix}sticker (reply image)
${c.prefix}quote   ${c.prefix}truth   ${c.prefix}dare
${c.prefix}joke    ${c.prefix}fact

🤖 *AI*
${c.prefix}ai <prompt>
${c.prefix}img <prompt>

> Powered by DarklordFarhan ⚡`;
      await sock.sendMessage(from, { text }, { quoted: msg });
    },
  },
  { name: "ping", run: async ({ sock, msg, from }) => { const t = Date.now(); await sock.sendMessage(from, { text: `🏓 Pong! ${Date.now() - t}ms` }, { quoted: msg }); } },
  { name: "alive", run: async ({ sock, msg, from, config: c }) => sock.sendMessage(from, { text: `✨ *${c.botName}* is alive and lurking in the dark.` }, { quoted: msg }) },
  {
    name: "owner",
    run: async ({ sock, msg, from, config: c }) => {
      await sock.sendMessage(from, {
        contacts: { displayName: c.ownerName, contacts: [{ vcard:
`BEGIN:VCARD\nVERSION:3.0\nFN:${c.ownerName}\nTEL;type=CELL;waid=${c.ownerNumber}:+${c.ownerNumber}\nEND:VCARD` }] },
      }, { quoted: msg });
    },
  },
  {
    name: "runtime",
    run: async ({ sock, msg, from }) => {
      const s = process.uptime();
      const h = Math.floor(s/3600), m = Math.floor((s%3600)/60), sec = Math.floor(s%60);
      await sock.sendMessage(from, { text: `⏱ Uptime: ${h}h ${m}m ${sec}s` }, { quoted: msg });
    },
  },
];

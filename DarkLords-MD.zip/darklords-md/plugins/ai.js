import axios from "axios";

async function chat(prompt, config) {
  if (!config.lovableApiKey) throw new Error("Set LOVABLE_API_KEY env");
  const { data } = await axios.post(
    "https://ai.gateway.lovable.dev/v1/chat/completions",
    { model: config.aiModel, messages: [{ role: "user", content: prompt }] },
    { headers: { Authorization: `Bearer ${config.lovableApiKey}`, "Content-Type": "application/json" }, timeout: 60000 }
  );
  return data.choices?.[0]?.message?.content || "(no reply)";
}

async function image(prompt, config) {
  if (!config.lovableApiKey) throw new Error("Set LOVABLE_API_KEY env");
  const { data } = await axios.post(
    "https://ai.gateway.lovable.dev/v1/chat/completions",
    { model: "google/gemini-2.5-flash-image", messages: [{ role: "user", content: prompt }], modalities: ["image", "text"] },
    { headers: { Authorization: `Bearer ${config.lovableApiKey}`, "Content-Type": "application/json" }, timeout: 90000 }
  );
  const url = data.choices?.[0]?.message?.images?.[0]?.image_url?.url;
  if (!url) throw new Error("No image returned");
  return Buffer.from(url.split(",")[1], "base64");
}

export default [
  { name: "ai", aliases: ["gpt", "ask"], run: async ({ sock, msg, from, args, config }) => {
    if (!args.length) throw new Error("Usage: .ai <prompt>");
    await sock.sendMessage(from, { text: "🧠 thinking..." }, { quoted: msg });
    await sock.sendMessage(from, { text: await chat(args.join(" "), config) }, { quoted: msg });
  }},
  { name: "img", aliases: ["image", "imagine"], run: async ({ sock, msg, from, args, config }) => {
    if (!args.length) throw new Error("Usage: .img <prompt>");
    await sock.sendMessage(from, { text: "🎨 generating..." }, { quoted: msg });
    const buf = await image(args.join(" "), config);
    await sock.sendMessage(from, { image: buf, caption: `🎨 ${args.join(" ")}` }, { quoted: msg });
  }},
];
